console.log("hello world");
var a=15;
var b=54;
var r=a+b;
console.log("suma es:"+ r);
//multiplicacion
var n=15;
var m=54;
var re=n*m;
console. log ("la multiplicacion es" + re);
//Raiz cuadrada
var raiz=Math.sqrt(1244);
console.log("la raiz cuadrada de 1244 es:"+ raiz);
//raiz entera
var raiz2=Math.trunc(raiz)
console.log("El resultado de la raiz aproximada es:" + raiz2);
//numeros primos hasta el 500000
var c = 500000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log("Los numero primos hasta el 500.000 son: " + numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}

